package com.example

import com.example.model.OutputProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleRobolectricTest {

  @Test
  fun `verify app logic and profile integrity`() {
    val profile = OutputProfile.HDR10
    assertEquals("HDR10", profile.title)
  }

  @Test
  fun `verify hdr profiles contain bt2020 and smpte2084 parameters`() {
    val hdr10 = OutputProfile.HDR10
    assertTrue(hdr10.x265Params.contains("colorprim=bt2020"))
    assertTrue(hdr10.x265Params.contains("transfer=smpte2084"))
    assertTrue(hdr10.x265Params.contains("colormatrix=bt2020nc"))

    val hdr10Plus = OutputProfile.HDR10_PLUS_MAX
    assertTrue(hdr10Plus.x265Params.contains("hdr10-opt=1"))
    assertTrue(hdr10Plus.x265Params.contains("aq-mode=3"))
  }
}
