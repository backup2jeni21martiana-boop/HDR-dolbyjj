package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PureBlack = Color(0xFF000000)
val DarkSurface = Color(0xFF0A0A0A)
val DarkElevated = Color(0xFF141414)
val DarkBorder = Color(0xFF222222)
val DarkBorderHighlight = Color(0x44FFC107)

val AmberPrimary = Color(0xFFFFC107)
val AmberLight = Color(0xFFFFD54F)
val AmberDark = Color(0xFFFFA000)
val AmberGlow = Color(0x22FFC107)
val AmberDim = Color(0xFF4A401A)
val AmberDeep = Color(0xFF332900)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB0B0B0)
val TextMuted = Color(0xFF757575)

val StatusSuccess = Color(0xFF4CAF50)
val StatusError = Color(0xFFE53935)
val StatusProcessing = Color(0xFFFFC107)
