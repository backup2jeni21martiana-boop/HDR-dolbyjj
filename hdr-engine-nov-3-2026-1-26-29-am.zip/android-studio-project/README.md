# HDR Engine - Android Studio Project

Proyek native Android Studio lengkap untuk **HDR Mastering Engine (SDR to Dolby Vision Profile 8.4 / HDR10 4K 120FPS)**.

## Fitur Utama
1. **Desain UI Pitch-Black & Amber**:
   - Background pekat `#000000` dengan aksen kontras `#FFC107`.
   - Card container tegas dengan garis pembatas emas (`#FFC107`).
   - Tombol full-width "PILIH VIDEO" dan "CONVERT TO DOLBY VISION".
2. **HDR Expansion (NITs)**:
   - Slider dinamis dari 400 hingga 2000 NITs (default 1000 NITs).
3. **Pipeline Dolby Vision Profile 8.4 (HEVC 4K 120FPS)**:
   - Native background threading via `ExecutorService`.
   - Pipeline filter: Lanczos 4K scaling, MCI 120FPS interpolation, BT.709 to linear, Mobius tonemapping, BT.2020 PQ linear transform, yuv420p10le, dan x265 Dolby Vision metadata injection.
   - Real-time progress bar dan percentage indicator dinamis.

## Cara Membuka di Android Studio
1. Buka Android Studio.
2. Pilih **File > Open...** dan arahkan ke folder `android-studio-project`.
3. Biarkan Gradle melakukan sync project.
4. Hubungkan perangkat Android fisik atau jalankan Emulator.
5. Klik **Run** (`Shift + F10`) untuk mengompilasi dan menginstal APK.
