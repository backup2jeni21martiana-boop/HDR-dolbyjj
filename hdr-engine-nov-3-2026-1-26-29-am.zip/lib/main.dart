import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:ffmpeg_kit_flutter_min_gpl/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_min_gpl/ffmpeg_kit_config.dart';
import 'package:ffmpeg_kit_flutter_min_gpl/ffprobe_kit.dart';
import 'package:ffmpeg_kit_flutter_min_gpl/return_code.dart';
import 'package:ffmpeg_kit_flutter_min_gpl/ffmpeg_session.dart';
import 'package:ffmpeg_kit_flutter_min_gpl/statistics.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const HDREngineApp());
}

class HDREngineApp extends StatelessWidget {
  const HDREngineApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HDR Engine',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF000000),
        primaryColor: const Color(0xFFFFC107),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFFFC107),
          secondary: Color(0xFFFFD54F),
          surface: Color(0xFF1E1E1E),
          background: Color(0xFF000000),
        ),
        fontFamily: 'monospace',
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  static const Color pureBlack = Color(0xFF000000);
  static const Color cardBackground = Color(0xFF1E1E1E);
  static const Color darkBorder = Color(0xFF2C2C2C);
  static const Color amberAccent = Color(0xFFFFC107);
  static const Color amberLight = Color(0xFFFFD54F);

  String _inputVideoPath = "Belum ada video dipilih";
  String? _outputVideoPath;
  String _processingStatus = "IDLE - STANDBY FOR COMMAND";
  bool _isProcessing = false;
  double _selectedNits = 1000.0;
  double _progressPercentage = 0.0;
  double _totalDurationMs = 1.0;
  final List<String> _logHistory = [];

  @override
  void dispose() {
    FFmpegKitConfig.enableStatisticsCallback(null);
    super.dispose();
  }

  // 1. SELECT VIDEO FROM DEVICE STORAGE
  Future<void> _pilihVideo() async {
    if (_isProcessing) return;

    try {
      final FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['mp4', 'mkv', 'mov', 'avi'],
      );

      if (result != null && result.files.single.path != null) {
        final String path = result.files.single.path!;
        setState(() {
          _inputVideoPath = path;
          _outputVideoPath = null;
          _processingStatus = "Video dimuat - Menghitung metadata stream...";
          _progressPercentage = 0.0;
          _logHistory.clear();
          _logHistory.add('> Source File: ${p.basename(path)}');
          _logHistory.add('> File Path: $path');
        });

        // Use FFprobeKit to extract video duration for real-time progress percentage
        try {
          final mediaInfoSession = await FFprobeKit.getMediaInformation(path);
          final mediaInfo = mediaInfoSession.getMediaInformation();
          if (mediaInfo != null) {
            final durationStr = mediaInfo.getDuration();
            if (durationStr != null) {
              final double durationSec = double.tryParse(durationStr) ?? 0.0;
              if (durationSec > 0) {
                _totalDurationMs = durationSec * 1000.0;
                setState(() {
                  _processingStatus = "Siap diproses: ${durationSec.toStringAsFixed(1)}s (1080p/4K)";
                  _logHistory.add('> Stream Duration: ${durationSec.toStringAsFixed(2)}s (${_totalDurationMs.toInt()} ms)');
                });
                return;
              }
            }
          }
        } catch (_) {
          // Fallback duration
        }

        _totalDurationMs = 15000.0; // 15 seconds default baseline fallback
        setState(() {
          _processingStatus = "Video siap dikonversi ke 4K 120FPS Dolby Vision.";
        });
      }
    } catch (e) {
      _showToast("Gagal memilih file video: $e", isError: true);
    }
  }

  // 2. CORE FFMPEG 4K 120FPS DOLBY VISION PIPELINE EXECUTION
  Future<void> _prosesKeDolbyVision() async {
    if (_inputVideoPath == "Belum ada video dipilih") {
      _showToast("Silakan pilih video terlebih dahulu!", isError: true);
      return;
    }

    final inputFile = File(_inputVideoPath);
    if (!await inputFile.exists()) {
      _showToast("File video sumber tidak ditemukan di penyimpanan!", isError: true);
      return;
    }

    setState(() {
      _isProcessing = true;
      _progressPercentage = 0.01;
      _processingStatus = "Memulai pipeline 4K 120FPS Dolby Vision Profile 8.4...";
      _logHistory.add('> Initializing hardware-compliant Dolby Vision graph...');
    });

    try {
      final originalDir = p.dirname(_inputVideoPath);
      final baseName = p.basenameWithoutExtension(_inputVideoPath);
      final outputName = '${baseName}_dv_4k_120.mp4';

      String targetDir = originalDir;
      try {
        final testFile = File(p.join(originalDir, '.perm_test'));
        await testFile.writeAsString('test');
        await testFile.delete();
      } catch (_) {
        final appDocDir = await getApplicationDocumentsDirectory();
        targetDir = appDocDir.path;
      }

      final outputPath = p.join(targetDir, outputName);
      final int nitsInt = _selectedNits.toInt();

      // Video Filter Pipeline: Lanczos 4K Upscale + MCI 120FPS + Zscale + Mobius Tone-mapping
      const String vfString =
          "scale=3840:2160:flags=lanczos,"
          "minterpolate=fps=120:mi_mode=mci:mc_mode=aobmc:vsbmc=1,"
          "zscale=t=linear:p=bt709,"
          "tonemap=tonemap=mobius:param=0.01:desat=0,"
          "zscale=p=bt2020:t=smpte2084:m=bt2020nc:r=tv,"
          "format=yuv420p10le";

      // x265 parameters injecting BT.2020, ST2084 PQ, D65 master display, and Dolby Vision Profile 8.4 flags
      final String x265Params =
          "colorprim=bt2020:transfer=smpte2084:colormatrix=bt2020nc:"
          "master-display=G(13250,34500)B(7500,3000)R(34000,16000)WP(15635,16450)L(10000000,1):"
          "max-cll=$nitsInt,0:dovi-sharing=1:dolby-vision=1";

      final String ffmpegCommand =
          "-y -i \"$_inputVideoPath\" "
          "-vf \"$vfString\" "
          "-c:v libx265 -preset ultrafast "
          "-x265-params \"$x265Params\" "
          "-r 120 -c:a copy \"$outputPath\"";

      _logHistory.add('> Upscaling: 3840x2160 (Lanczos)');
      _logHistory.add('> Frame Engine: 120 FPS Motion Compensated Interpolation (MCI)');
      _logHistory.add('> Color Science: Rec.709 Linear -> Mobius HDR Tonemap -> BT.2020 PQ 10-bit');
      _logHistory.add('> Metadata: Dolby Vision Profile 8.4 ($nitsInt NITs Peak)');
      _logHistory.add('> Executing: ffmpeg $ffmpegCommand');

      // 3. REAL-TIME PROGRESS TRACKING VIA STATISTICS CALLBACK
      FFmpegKitConfig.enableStatisticsCallback((Statistics statistics) {
        if (!mounted || !_isProcessing) return;
        final int timeInMs = statistics.getTime();
        if (timeInMs > 0 && _totalDurationMs > 0) {
          final double computed = (timeInMs / _totalDurationMs).clamp(0.01, 0.99);
          setState(() {
            _progressPercentage = computed;
            _processingStatus = "Sedang mengonversi: ${(computed * 100).toStringAsFixed(1)}% (FPS: ${statistics.getVideoFps().toStringAsFixed(1)})";
          });
        }
      });

      // 4. ASYNCHRONOUS FFMPEG EXECUTION
      await FFmpegKit.executeAsync(
        ffmpegCommand,
        (FFmpegSession session) async {
          FFmpegKitConfig.enableStatisticsCallback(null);
          final returnCode = await session.getReturnCode();
          final failStackTrace = await session.getFailStackTrace();

          if (mounted) {
            setState(() {
              _isProcessing = false;
            });

            if (ReturnCode.isSuccess(returnCode)) {
              setState(() {
                _progressPercentage = 1.0;
                _outputVideoPath = outputPath;
                _processingStatus = "Sukses! Dolby Vision Profile 8.4 Aktif.\nTersimpan di:\n$outputPath";
                _logHistory.add('> 100% SUCCESS: Dolby Vision Master ready at $outputPath');
              });
              _showToast("Konversi Berhasil! Tersimpan: $outputName", isError: false);
            } else {
              setState(() {
                _progressPercentage = 0.0;
                _processingStatus = "Gagal memproses video. Pastikan format video didukung.";
                _logHistory.add('> Terminated with ReturnCode: $returnCode');
                if (failStackTrace != null) {
                  _logHistory.add('> StackTrace: $failStackTrace');
                }
              });
              _showToast("Gagal memproses video. ReturnCode: $returnCode", isError: true);
            }
          }
        },
        (log) {
          if (mounted) {
            setState(() {
              if (_logHistory.length > 50) {
                _logHistory.removeAt(0);
              }
              _logHistory.add(log.getMessage());
            });
          }
        },
      );
    } catch (e) {
      FFmpegKitConfig.enableStatisticsCallback(null);
      setState(() {
        _isProcessing = false;
        _progressPercentage = 0.0;
        _processingStatus = "Terjadi kesalahan: $e";
      });
      _showToast("Terjadi kesalahan: $e", isError: true);
    }
  }

  void _showToast(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: TextStyle(
            color: isError ? Colors.white : pureBlack,
            fontWeight: FontWeight.bold,
            fontFamily: 'monospace',
          ),
        ),
        backgroundColor: isError ? Colors.redAccent : amberAccent,
        duration: const Duration(seconds: 4),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Widget _buildSectionCard({required String title, required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cardBackground,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: amberAccent.withOpacity(0.5), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: amberAccent,
              fontWeight: FontWeight.bold,
              fontSize: 12,
              letterSpacing: 1.2,
              fontFamily: 'monospace',
            ),
          ),
          const SizedBox(height: 8),
          const Divider(color: amberAccent, thickness: 1, height: 1),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: pureBlack,
      appBar: AppBar(
        title: const Text(
          'HDR ENGINE',
          style: TextStyle(
            color: amberAccent,
            fontWeight: FontWeight.w900,
            letterSpacing: 2,
            fontFamily: 'monospace',
          ),
        ),
        centerTitle: true,
        backgroundColor: pureBlack,
        elevation: 0,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. Header Card
              _buildSectionCard(
                title: "H HDR MASTERING ENGINE",
                child: const Text(
                  "SDR → Dolby Vision Profile 8.4 menggunakan HEVC Main10, BT.2020, MCI 120FPS, dan PQ/ST2084 untuk kompatibilitas penuh TikTok HDR.",
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                    fontFamily: 'monospace',
                    height: 1.4,
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // 2. Source Video Card
              _buildSectionCard(
                title: "▪ SOURCE VIDEO",
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: amberAccent,
                        foregroundColor: pureBlack,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                      ),
                      onPressed: _isProcessing ? null : _pilihVideo,
                      icon: const Icon(Icons.folder_open, color: pureBlack, size: 20),
                      label: const Text(
                        'PILIH VIDEO',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 1.2, fontFamily: 'monospace'),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: pureBlack,
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(color: darkBorder),
                      ),
                      child: Text(
                        _inputVideoPath,
                        style: TextStyle(
                          fontSize: 11,
                          color: _inputVideoPath != "Belum ada video dipilih" ? amberLight : Colors.grey[500],
                          fontFamily: 'monospace',
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // 3. Frame Rate Engine Card
              _buildSectionCard(
                title: "▪ FRAME RATE ENGINE",
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
                  decoration: BoxDecoration(
                    color: pureBlack,
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: amberAccent.withOpacity(0.5)),
                  ),
                  child: Row(
                    children: [
                      Radio<bool>(
                        value: true,
                        groupValue: true,
                        activeColor: amberAccent,
                        onChanged: (val) {},
                      ),
                      const SizedBox(width: 4),
                      const Expanded(
                        child: Text(
                          "120 FPS (Motion Compensated Interpolation)",
                          style: TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.bold,
                            color: amberAccent,
                            fontFamily: 'monospace',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // 4. HDR Expansion Card (NITs)
              _buildSectionCard(
                title: "▪ HDR EXPANSION (NITs)",
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          "Peak Brightness:",
                          style: TextStyle(fontSize: 12, color: Colors.white70, fontFamily: 'monospace'),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: pureBlack,
                            borderRadius: BorderRadius.circular(4),
                            border: Border.all(color: amberAccent.withOpacity(0.6)),
                          ),
                          child: Text(
                            "${_selectedNits.toInt()} NITs",
                            style: const TextStyle(
                              color: amberAccent,
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                              fontFamily: 'monospace',
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        activeTrackColor: amberAccent,
                        inactiveTrackColor: const Color(0xFF333333),
                        thumbColor: amberAccent,
                        overlayColor: amberAccent.withOpacity(0.2),
                        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
                        trackHeight: 4,
                      ),
                      child: Slider(
                        value: _selectedNits,
                        min: 400.0,
                        max: 2000.0,
                        divisions: 16,
                        onChanged: _isProcessing
                            ? null
                            : (double value) {
                                setState(() {
                                  _selectedNits = value;
                                });
                              },
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("400 NITs", style: TextStyle(fontSize: 9, color: Colors.grey[500], fontFamily: 'monospace')),
                        Text("1000 NITs (Master)", style: TextStyle(fontSize: 9, color: Colors.grey[500], fontFamily: 'monospace')),
                        Text("2000 NITs (Max)", style: TextStyle(fontSize: 9, color: Colors.grey[500], fontFamily: 'monospace')),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // 5. Processing Status Card
              _buildSectionCard(
                title: "▪ PROCESSING STATUS",
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      _processingStatus,
                      style: const TextStyle(fontSize: 11, color: Colors.white, fontFamily: 'monospace'),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          "Progress:",
                          style: TextStyle(fontSize: 11, color: Colors.grey, fontFamily: 'monospace'),
                        ),
                        Text(
                          "${(_progressPercentage * 100).toStringAsFixed(1)}%",
                          style: const TextStyle(
                            fontSize: 11,
                            color: amberAccent,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'monospace',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(2),
                      child: LinearProgressIndicator(
                        value: _progressPercentage > 0 ? _progressPercentage : null,
                        backgroundColor: const Color(0xFF2C2C2C),
                        color: amberAccent,
                        minHeight: 6,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      height: 80,
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: pureBlack,
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(color: darkBorder),
                      ),
                      child: _logHistory.isEmpty
                          ? const Text(
                              '> SYSTEM READY\n> AWAITING COMMAND...',
                              style: TextStyle(color: amberAccent, fontSize: 10, fontFamily: 'monospace'),
                            )
                          : ListView.builder(
                              reverse: true,
                              itemCount: _logHistory.length,
                              itemBuilder: (context, index) {
                                final log = _logHistory[_logHistory.length - 1 - index];
                                return Text(
                                  log,
                                  style: TextStyle(
                                    color: log.contains('ERROR') || log.contains('Gagal')
                                        ? Colors.redAccent
                                        : amberLight,
                                    fontSize: 9.5,
                                    fontFamily: 'monospace',
                                  ),
                                );
                              },
                            ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // 6. Action Button
              SizedBox(
                height: 52,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: amberAccent,
                    disabledBackgroundColor: const Color(0xFF332900),
                    foregroundColor: pureBlack,
                    disabledForegroundColor: Colors.white30,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                  ),
                  onPressed: _isProcessing ? null : _prosesKeDolbyVision,
                  child: _isProcessing
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Text(
                              'CONVERTING: ${(_progressPercentage * 100).toStringAsFixed(1)}%',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                                letterSpacing: 1.2,
                                color: Colors.white,
                                fontFamily: 'monospace',
                              ),
                            ),
                          ],
                        )
                      : const Text(
                          'CONVERT TO DOLBY VISION',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            letterSpacing: 1.5,
                            fontFamily: 'monospace',
                          ),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
