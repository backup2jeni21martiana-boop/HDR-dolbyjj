import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:ffmpeg_kit_flutter_min_gpl/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_min_gpl/ffmpeg_kit_config.dart';
import 'package:ffmpeg_kit_flutter_min_gpl/return_code.dart';
import 'package:ffmpeg_kit_flutter_min_gpl/ffprobe_kit.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const HDREngineApp());
}

class HDREngineApp extends StatelessWidget {
  const HDREngineApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HDR Engine',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF000000),
        colorScheme: const ColorScheme.dark(primary: Colors.amber),
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  String _inputVideoPath = "Belum ada video dipilih";
  String _processingStatus = "Output: belum dibuat";
  bool _isProcessing = false;
  double _selectedNits = 1000.0;
  double _progressPercentage = 0.0;
  double _totalDurationMs = 1.0;

  @override
  void dispose() {
    FFmpegKitConfig.enableStatisticsCallback(null);
    super.dispose();
  }

  // Fungsi untuk memilih file video dari penyimpanan internal HP
  void _pilihVideo() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(type: FileType.video);
    
    if (result != null && result.files.single.path != null) {
      String path = result.files.single.path!;
      setState(() {
        _inputVideoPath = path;
        _processingStatus = "Video siap dikonversi.";
        _progressPercentage = 0.0;
      });

      // Dapatkan durasi video asli menggunakan FFprobe untuk kalkulasi persentase progres
      FFprobeKit.getMediaInformation(path).then((session) async {
        final info = session.getMediaInformation();
        if (info != null) {
          final durationStr = info.getDuration();
          if (durationStr != null) {
            double durationSec = double.tryParse(durationStr) ?? 0.0;
            if (durationSec > 0) {
              _totalDurationMs = durationSec * 1000.0;
            }
          }
        }
      });
    }
  }

  // Fungsi Inti: Konversi Video ke 4K 120FPS Dolby Vision + Progress Tracker
  void _prosesKeDolbyVision() async {
    if (_inputVideoPath == "Belum ada video dipilih") {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Silakan pilih video terlebih dahulu!'))
      );
      return;
    }

    setState(() {
      _isProcessing = true;
      _progressPercentage = 0.0;
      _processingStatus = "Memulai pipeline Dolby Vision...";
    });

    String outputPath = _inputVideoPath.replaceAll('.mp4', '_dv_4k_120.mp4');
    if (!outputPath.endsWith('.mp4')) {
      outputPath = '${_inputVideoPath}_dv_4k_120.mp4';
    }
    int nitsInt = _selectedNits.toInt();

    // Aktifkan callback statistik untuk menghitung persentase secara real-time
    FFmpegKitConfig.enableStatisticsCallback((statistics) {
      int timeInMs = statistics.getTime();
      if (timeInMs > 0 && _totalDurationMs > 0) {
        setState(() {
          _progressPercentage = (timeInMs / _totalDurationMs).clamp(0.0, 1.0);
          _processingStatus = "Sedang memproses konversi ke Dolby Vision...";
        });
      }
    });

    // Perintah FFMPEG Teroptimasi: 4K Resolution, 120FPS MCI, True HDR Tonemapping, dan Dolby Vision Flags
    String ffmpegCommand = 
        "-i \"$_inputVideoPath\" -vf \"scale=3840:2160:flags=lanczos,minterpolate=fps=120:mi_mode=mci:mc_mode=aobmc:vsbmc=1,zscale=t=linear:p=bt709,tonemap=tonemap=mobius:param=0.01:desat=0,zscale=p=bt2020:t=smpte2084:m=bt2020nc:r=tv,format=yuv420p10le\" "
        "-c:v libx265 -preset ultrafast -x265-params \"colorprim=bt2020:transfer=smpte2084:colormatrix=bt2020nc:master-display=G(13250,34500)B(7500,3000)R(34000,16000)WP(15635,16450)L(10000000,1):max-cll=$nitsInt,0:dovi-sharing=1:dolby-vision=1\" "
        "-r 120 -c:a copy \"$outputPath\"";

    await FFmpegKit.executeAsync(ffmpegCommand, (session) async {
      final returnCode = await session.getReturnCode();
      FFmpegKitConfig.enableStatisticsCallback(null); // Matikan callback setelah selesai

      setState(() {
        _isProcessing = false;
        if (ReturnCode.isSuccess(returnCode)) {
          _progressPercentage = 1.0;
          _processingStatus = "Sukses! Dolby Vision Aktif.\nTersimpan di:\n$outputPath";
        } else {
          _progressPercentage = 0.0;
          _processingStatus = "Gagal memproses video. Pastikan format video didukung.";
        }
      });
    });
  }

  Widget _buildSectionCard({required String title, required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: Colors.amber.withOpacity(0.5), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.amber,
              fontWeight: FontWeight.bold,
              fontSize: 12,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 8),
          const Divider(color: Colors.amber, thickness: 1, height: 1),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('HDR ENGINE', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2)),
        centerTitle: true,
        backgroundColor: Colors.black,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Header Info
            _buildSectionCard(
              title: "H HDR MASTERING ENGINE",
              child: const Text(
                "SDR → Dolby Vision Profile 8.4 menggunakan HEVC Main10, BT.2020, MCI 120FPS, dan PQ/ST2084 untuk kompatibilitas penuh TikTok HDR.",
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ),
            const SizedBox(height: 16),

            // Source Video Card
            _buildSectionCard(
              title: "▪ SOURCE VIDEO",
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.amber, 
                      foregroundColor: Colors.black,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                      elevation: 0,
                    ),
                    onPressed: _isProcessing ? null : _pilihVideo,
                    child: const Text('PILIH VIDEO', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                  const SizedBox(height: 8),
                  Text(_inputVideoPath, style: const TextStyle(fontSize: 11, color: Colors.amber)),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Frame Rate Engine Card
            _buildSectionCard(
              title: "▪ FRAME RATE ENGINE",
              child: Row(
                children: [
                  Radio<bool>(
                    value: true, 
                    groupValue: true, 
                    activeColor: Colors.amber,
                    onChanged: (val) {},
                  ),
                  const Expanded(
                    child: Text(
                      "120 FPS (Motion Compensated Interpolation)", 
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.amber),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // HDR Expansion Card
            _buildSectionCard(
              title: "▪ HDR EXPANSION (NITs)",
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.between,
                    children: [
                      const Text("Peak Brightness:", style: TextStyle(fontSize: 12)),
                      Text("${_selectedNits.toInt()} NITs", style: const TextStyle(color: Colors.amber, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  Slider(
                    value: _selectedNits,
                    min: 400.0,
                    max: 2000.0,
                    divisions: 16,
                    activeColor: Colors.amber,
                    inactiveColor: Colors.grey[800],
                    onChanged: _isProcessing ? null : (double value) {
                      setState(() {
                        _selectedNits = value;
                      });
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Processing Status Card
            _buildSectionCard(
              title: "▪ PROCESSING STATUS",
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(_processingStatus, style: const TextStyle(fontSize: 12, color: Colors.white)),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.between,
                    children: [
                      const Text("Progress:", style: TextStyle(fontSize: 11, color: Colors.grey)),
                      Text("${(_progressPercentage * 100).toStringAsFixed(1)}%", style: const TextStyle(fontSize: 11, color: Colors.amber, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  LinearProgressIndicator(
                    value: _progressPercentage > 0 ? _progressPercentage : null,
                    backgroundColor: Colors.grey[900],
                    color: Colors.amber,
                    minHeight: 6,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Tombol Utama Convert
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.amber,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.all(16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                elevation: 0,
              ),
              onPressed: _isProcessing ? null : _prosesKeDolbyVision,
              child: const Text('CONVERT TO DOLBY VISION', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, letterSpacing: 1)),
            ),
          ],
        ),
      ),
    );
  }
}
